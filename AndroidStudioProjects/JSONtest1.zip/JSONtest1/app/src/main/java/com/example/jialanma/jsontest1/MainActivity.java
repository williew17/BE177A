package com.example.jialanma.jsontest1;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Iterator;

public class MainActivity extends AppCompatActivity {

    AmazonS3 s3Client;
    String bucket = "quanhaibucket";
    File uploadit = new File("/data/user/0/com.example.jialanma.jsontest1/files/config.txt");
    File downloadit = new File("/data/user/0/com.example.jialanma.jsontest1/files/config.txt");
    TransferUtility transferUtility;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        s3credentialsProvider();

        setTransferUtility();
        String J = JSONObj();
        Log.d("json",J);
        writeToFile(J);

        // Find path of the saved JSON file
        File file = new File(getFilesDir() + "/" + "config.txt");
        String dir = file.getAbsolutePath();
        Log.d("pathname",dir);

/* Count the number of name/value pairs in a JSON object
*
        String J = JSONObj();
        try {
            JSONObject jsoniter = new JSONObject(J);
            Iterator<String> iter = jsoniter.keys();
            while (iter.hasNext()){
                String key = iter.next();
                try {
                    Object value = jsoniter.get(key);
                    Log.d("length",""+value);
                } catch (JSONException e){
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
*/


/* Test if a JSON obect is correctly created
*
        String J = JSONObj();
        try {
            JSONObject jsontest = new JSONObject(J);
            String ans1 = jsontest.getString("Q2");
            Log.d("ans",ans1);
        } catch (JSONException e) {
            e.printStackTrace();
        }
*/

    }

    // Save a JSON file
    public void writeToFile(String data){
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(openFileOutput("config.txt", Context.MODE_PRIVATE));
            outputStreamWriter.write(data);
            outputStreamWriter.close();
        } catch (IOException e){
            Log.e("Exception","File write failed: "+ e.toString());
        }
    }



    public void s3credentialsProvider(){
        // Initialize the AWS Credential
        CognitoCachingCredentialsProvider cognitoCachingCredentialsProvider =
                new CognitoCachingCredentialsProvider(
                        getApplicationContext(),
                        "us-east-1:b942d0f3-2da3-44f5-86a9-621c47f04aa1", // Identity Pool ID
                        Regions.US_EAST_1 // Region
                );
        createAmazonS3Client(cognitoCachingCredentialsProvider);
    }

    public void createAmazonS3Client(CognitoCachingCredentialsProvider credentialsProvider){
        // Create an S3 client
        s3Client = new AmazonS3Client(credentialsProvider);

        // Set the region of your S3 bucket
        s3Client.setRegion(Region.getRegion(Regions.US_EAST_1));
    }

    public void setTransferUtility(){
        transferUtility = new TransferUtility(s3Client, getApplicationContext());
    }

    public void uploadtoS3(View view){
        TransferObserver transferObserver = transferUtility.upload(
                bucket,
                "config.txt",
                uploadit
        );

        transferObserverListener(transferObserver);
    }

    public void downloadfromS3(View view){
        TransferObserver transferObserver = transferUtility.download(
                bucket,
                "config.txt",
                downloadit
        );


        transferObserverListener(transferObserver);

    }

    public void transferObserverListener(TransferObserver transferObserver) {

        transferObserver.setTransferListener(new TransferListener() {

            @Override
            public void onStateChanged(int id, TransferState state) {
                Toast.makeText(getApplicationContext(), "State Change"
                        + state, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                int percentage = (int) (bytesCurrent / bytesTotal * 100);
                Toast.makeText(getApplicationContext(), "Progress in %"
                        + percentage, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(int id, Exception ex) {
                Log.e("error", "error");
            }

        });
    }

    /* Create a JSON object
    *  {
    *  "Q1": "1"
    *  "Q2": "2"
    *  "Q3": "3"
    *  "Q4": "4"
    *  "Q5": "5"
    * }
     */

    public static String JSONObj(){
        JSONObject jsonObject = new JSONObject();
        try{
            jsonObject.put("Q1","1");
            jsonObject.put("Q2","2");
            jsonObject.put("Q3","3");
            jsonObject.put("Q4","4");
            jsonObject.put("Q5","5");


        } catch (JSONException e){
            e.printStackTrace();
        }
        return jsonObject.toString();
    }

}